<div align="center">
  <img src="includes/assets/images/logo.png" alt="TataPlay Logo" width="150" height="150">
  <h1>TataPlay Localhost Playlist (Widevine)</h1>
  <p>Crafted with ❤️ by <b>LazyyXD</b></p>
</div>

<p align="center">
  <b>A PHP-based web portal to generate M3U playlists for Tata Play. Watch DRM-protected live TV channels locally via an integrated web player, or use the generated playlist on your preferred IPTV apps!</b>
</p>

---

## 📑 Table of Contents
- [🌟 Features](#-features)
- [🚀 Getting Started](#-getting-started)
  - [1️⃣ Prerequisites \& Server Setup](#1️⃣-prerequisites--server-setup)
  - [2️⃣ Download \& Setup Script](#2️⃣-download--setup-script)
- [💻 Usage Guide](#-usage-guide)
  - [🔐 How to Login](#-how-to-login)
  - [▶️ Accessing the M3U Playlist](#️-accessing-the-m3u-playlist)
- [❓ Troubleshooting / FAQ](#-troubleshooting--faq)
- [📂 Project Structure](#-project-structure)
- [⚖️ Disclaimer \& License](#️-disclaimer--license)

---

## 🌟 Features

### Core Functionality
- **Tata Play Authentication:** Log in directly using your Tata Play account credentials.
- **M3U Playlist Generation:** Auto-generates a dynamic `playlist.m3u` file compatible with Kodi (via `inputstream.adaptive`),Tivimate, Televizo, and other modern IPTV players that support Widevine DRM.
- **Integrated Web Player:** Watch live TV directly in your browser using the built-in Shaka Player interface.
- **Modern UI:** Sleek, responsive, and modern dark-themed user interface.

### ☠️ Advanced Capabilities
- **7 Days Catchup Support:** Available for supported channels.
  > ⚠️ **Note:** Currently, the catchup is not enabled due to frequent key rotations in many channels. Catchup will be available in future updates.
- **Automatic Token Extraction:** Extracts required tokens automatically.
- **Secure API Client:** Centralized HTTP request handler for interacting seamlessly with the Tata Play API.
- **Token Refresh System:** Built-in mechanism to refresh access tokens, ensuring uninterrupted playback and long-term session validity.
- **Local DRM Proxy:** Automatically proxies manifest and license requests to fetch Widevine keys and bypass CORS issues.
- **Well-Structured Cache System:** Optimized performance and reliability.

---

## 🚀 Getting Started

### 1️⃣ Prerequisites & Server Setup
Ensure you have the following installed before proceeding:
- **PHP 7.4 or higher** (PHP 8.x recommended)
- **`cURL` PHP extension** enabled
- A **Web server** (Apache or LiteSpeed are required as the project uses a `.htaccess` file)

**Recommended Web Servers:**
- For Mobiles &rarr; [KSWEB PRO v3.987](https://tsneh.vercel.app/ksweb_3.987.apk)
- For PC (Windows) &rarr; [XAMPP](https://www.apachefriends.org/download.html)

### 2️⃣ Download & Setup Script
1. Download the **[Script Zip File](https://github.com/lazyop/tataplay/archive/refs/heads/main.zip)** from the GitHub repository.
2. Extract all files into the `htdocs` under the `tataplay` folder in your file manager (path may vary for XAMPP):

   ```text
   📁 FileManager
   └── 📁 htdocs/
       └── 📁 tataplay/
           ├── 📄 playlist.php
           ├── 📄 login.php
           ├── 📄 index.php
           ├── 📄 player.php
           └── 📄 ....
   ```

3. Open the **KSWEB app** (or **XAMPP** for PC) and start the **APACHE/LiteSpeed** server.
4. The setup is complete, and the script is ready to use!

---

## 💻 Usage Guide

### 🔐 How to Login
Open the Login page (use port 80 for XAMPP):

`http://localhost:8000/tataplay/login`
- Login with your TATAPLAY subscriber ID.
- Enter the OTP received on your registered mobile number.

> ⚠️ **Note:** The account you use must be an **Active Account**.

### ▶️ Accessing the M3U Playlist
After logging in, use the following playlist link on your preferred IPTV Players (use port 80 for XAMPP):

`http://localhost:8000/tataplay/playlist.m3u`

🎉 **Enjoy TataPlay Channels with 7-day Catchup!**

---

## ❓ Troubleshooting / FAQ

- **"Apache won't start in XAMPP"** &rarr; Ensure that Port 80 is not being blocked by Skype, IIS, or another background service.
- **"OTP isn't arriving"** &rarr; Double-check that the Tata Play account you are using has an **active** subscription.
- **"Channels are not playing on Tivimate"** &rarr; Ensure you have copied the playlist URL exactly as shown, and that the device running Tivimate is connected to the same local network as your server.

---

## 📂 Project Structure

```text
📁 tataplay/
├── 📁 api/                    # API endpoints for authentication and token refreshing
│   ├── 📄 auth.php            # Handles the API authentication flow
│   └── 📄 refresh.php         # Script to refresh expired tokens
├── 📁 includes/               # Core logic, configurations, and static assets
│   ├── 📁 assets/             # UI static assets
│   │   ├── 📁 css/            # Cascading Style Sheets
│   │   ├── 📁 images/         # Image assets for the frontend
│   │   └── 📁 js/             # JavaScript files for interactive functionality
│   ├── 📁 core/               # Core PHP scripts and classes
│   │   ├── 📄 api-client.php  # Handles HTTP API requests and responses
│   │   ├── 📄 auth.php        # Internal authentication utilities
│   │   ├── 📄 cache.php       # Caching mechanism to reduce redundant requests
│   │   ├── 📄 channel-utils.php # Utilities for parsing and formatting channel data
│   │   ├── 📄 config.php      # Core configuration settings for the portal
│   │   ├── 📄 drm.php         # Logic related to Digital Rights Management (DRM)
│   │   └── 📄 functions.php   # Miscellaneous helper functions
│   └── 📁 data/               # JSON storage files
│       ├── 📄 channels.json   # Cached list of channel metadata
│       ├── 📄 stream_url.json # Cache of resolved stream URLs
│       └── 📄 tp-account.json # Stored Tata Play account details and tokens
├── 📁 uplink/                 # Proxy scripts for CORS bypass and DRM handling
│   ├── 📄 license.php         # Proxy for fetching Widevine DRM licenses
│   └── 📄 stream.php          # Proxy for handling DASH manifests and stream fragments
├── 📄 .htaccess               # Apache web server configuration for access control
├── 📄 index.php               # Main dashboard displaying the channel grid
├── 📄 login.php               # The login page user interface
├── 📄 logout.php              # Script to clear the active session
├── 📄 player.php              # Integrated Shaka Player interface for web playback
└── 📄 playlist.php            # Generates the dynamic M3U formatted playlist
```

---

## ⚖️ Disclaimer & License

- **This repository does not host, store, or distribute any pirated content.**
- **We are not affiliated with, nor endorsed by, Tata Play.**
- **This code simply automates the extraction of your own legally obtained keys.**
- This project is **ONLY** for educational purposes.
- **DO NOT** sell this script - it's 💯% FREE.
- Use responsibly and ethically.

### License
This project is open-source and available under the **MIT License**.
