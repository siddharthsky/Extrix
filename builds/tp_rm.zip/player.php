<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/includes/core/config.php';
require_once __DIR__ . '/includes/core/functions.php';

$id = $_GET['id'] ?? '';
$originalId = str_replace('ts', '', $id);

if (empty($originalId) || !is_numeric($originalId)) {
    die("Invalid Channel ID");
}

$channels = ChannelUtils::loadAll();

$channelInfo = null;
foreach ($channels as $ch) {
    if ($ch['tvg_id'] === "ts$originalId") {
        $channelInfo = $ch;
        break;
    }
}

if (!$channelInfo) {
    die("Channel not found");
}

$channelName = $channelInfo['tvg_name'] ?? "Channel $originalId";
$groupTitle = $channelInfo['group_title'] ?? 'Other';
$cleanGroupTitle = trim(preg_replace('/^TPlay\s*\|\s*/i', '', $groupTitle));

// Build base URL robustly using helper
$baseUrl = getBaseUrl();

$channelLogo = $channelInfo['tvg_logo'] ?? "$baseUrl/includes/assets/images/favicon.ico";
$streamUrl = "$baseUrl/ts$originalId/stream/lazyyxd.mpd";
$licenseUrl = "$baseUrl/ts$originalId/license";

// Related channels
$relatedChannels = [];
foreach ($channels as $ch) {
    if (($ch['group_title'] ?? '') === $groupTitle && $ch['tvg_id'] !== "ts$originalId") {
        $relatedChannels[] = $ch;
        if (count($relatedChannels) >= 15)
            break;
    }
}

// Fetch EPG
$epgData = ChannelUtils::fetchEpg($originalId);
$epgJson = json_encode($epgData);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title><?= htmlspecialchars($channelName) ?> - Tata Play Web</title>
    <link rel="shortcut icon" href="<?= htmlspecialchars($baseUrl) ?>/includes/assets/images/favicon.ico"
        type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/shaka-player@4.7.11/dist/controls.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mux.js/7.0.3/mux.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/shaka-player@4.7.11/dist/shaka-player.ui.min.js"></script>
    <style>
        :root {
            --bg: #07070a;
            --surface: #0e0e14;
            --surface-2: #15151f;
            --border: rgba(255, 255, 255, 0.06);
            --border-hover: rgba(57, 255, 20, 0.3);
            --green: #39ff14;
            --green-dim: rgba(57, 255, 20, 0.15);
            --green-glow: rgba(57, 255, 20, 0.25);
            --red: #ff4d4d;
            --text: #f0f0f5;
            --muted: #a0a0b8;
            --ff-head: 'Space Grotesk', sans-serif;
            --ff-body: 'Space Grotesk', sans-serif;
            --mono: 'JetBrains Mono', monospace;
            --r: 12px;
        }

        *,
        *::before,
        *::after {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        html,
        body {
            height: 100%;
            width: 100%;
            overflow: hidden;
            background: var(--bg);
            color: var(--text);
            font-family: var(--ff-body);
            -webkit-font-smoothing: antialiased;
        }

        * {
            scrollbar-width: thin;
            scrollbar-color: var(--green-dim) transparent;
        }

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: transparent;
        }

        ::-webkit-scrollbar-thumb {
            background: var(--green-dim);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--green);
        }

        .stage {
            position: relative;
            z-index: 10;
            width: 100vw;
            height: 100vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .topbar {
            flex-shrink: 0;
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 12px 24px;
            background: rgba(14, 14, 20, 0.7);
            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);
            border-bottom: 1px solid var(--border);
            z-index: 100;
        }

        .back-btn {
            display: flex;
            align-items: center;
            gap: 7px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 8px 14px;
            color: var(--text);
            font-weight: 500;
            font-size: 13px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s;
            white-space: nowrap;
        }

        .back-btn:hover {
            background: var(--green-dim);
            border-color: var(--green-glow);
            color: var(--green);
            box-shadow: 0 0 15px var(--green-glow);
        }

        .back-btn svg {
            width: 16px;
            height: 16px;
            stroke: currentColor;
            fill: none;
            stroke-width: 2.5;
            stroke-linecap: round;
        }

        .topbar-channel {
            flex: 1;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }

        .topbar-logo {
            width: 32px;
            height: 32px;
            object-fit: contain;
            border-radius: 6px;
            background: var(--surface-2);
            padding: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .topbar-name {
            font-family: var(--ff-head);
            font-size: 16px;
            font-weight: 700;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .live-badge {
            flex-shrink: 0;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 12px;
            border-radius: 100px;
            background: rgba(255, 77, 77, 0.1);
            color: var(--red);
            border: 1px solid rgba(255, 77, 77, 0.2);
            font-size: 11px;
            font-weight: 700;
            font-family: var(--mono);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .live-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--red);
            animation: blink 1.5s ease-in-out infinite;
            box-shadow: 0 0 8px var(--red);
        }

        @keyframes blink {

            0%,
            100% {
                opacity: 1;
                transform: scale(1);
            }

            50% {
                opacity: 0.4;
                transform: scale(0.8);
            }
        }

        .player-main {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            overflow-x: hidden;
        }

        .video-wrap {
            position: relative;
            width: 100%;
            background: #000;
            flex-shrink: 0;
            display: flex;
            justify-content: center;
            border-bottom: 1px solid var(--border);
        }

        .video-aspect {
            position: relative;
            width: 100%;
            max-width: 1400px;
            aspect-ratio: 16/9;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.8);
        }

        #player-video {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            background: #000;
            outline: none;
        }

        .ov {
            position: absolute;
            inset: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 16px;
            z-index: 20;
        }

        .ov-loading {
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(8px);
            transition: opacity 0.3s;
        }

        .ov-loading.hidden {
            opacity: 0;
            pointer-events: none;
        }

        .spinner {
            width: 42px;
            height: 42px;
            border: 3px solid rgba(57, 255, 20, 0.1);
            border-top-color: var(--green);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            box-shadow: 0 0 15px var(--green-glow);
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .ov-loading-text {
            font-size: 12px;
            font-weight: 600;
            color: var(--green);
            letter-spacing: 2px;
            text-transform: uppercase;
            font-family: var(--mono);
        }

        .ov-error {
            background: rgba(7, 7, 10, 0.95);
            backdrop-filter: blur(10px);
            display: none;
        }

        .ov-error.show {
            display: flex;
        }

        .err-icon {
            width: 48px;
            height: 48px;
            stroke: var(--red);
            fill: none;
            stroke-width: 1.5;
            filter: drop-shadow(0 0 10px rgba(255, 77, 77, 0.4));
        }

        .err-title {
            font-family: var(--ff-head);
            font-size: 18px;
            font-weight: 700;
            color: var(--text);
        }

        .err-msg {
            font-size: 13px;
            color: var(--muted);
            text-align: center;
            max-width: 360px;
            line-height: 1.6;
        }

        .retry-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            background: var(--green-dim);
            border: 1px solid var(--green-glow);
            border-radius: 8px;
            padding: 10px 24px;
            color: var(--green);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            font-family: var(--ff-head);
        }

        .retry-btn:hover {
            background: rgba(57, 255, 20, 0.25);
            border-color: var(--green);
            box-shadow: 0 0 20px var(--green-glow);
        }

        .retry-btn svg {
            width: 16px;
            height: 16px;
            stroke: currentColor;
            fill: none;
            stroke-width: 2.5;
        }

        .below-player {
            display: flex;
            flex-direction: column;
            background: var(--bg);
        }

        .now-playing {
            display: none;
            flex-direction: column;
            gap: 6px;
            padding: 24px;
            border-bottom: 1px solid var(--border);
        }

        .now-playing.visible {
            display: flex;
        }

        .np-label {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--green);
            font-family: var(--mono);
            margin-bottom: 4px;
            text-shadow: 0 0 10px var(--green-glow);
        }

        .np-label .dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--green);
            animation: blink 1.6s infinite;
        }

        .np-title {
            font-family: var(--ff-head);
            font-size: clamp(18px, 4vw, 26px);
            font-weight: 700;
            color: var(--text);
            line-height: 1.3;
        }

        .np-times {
            font-size: 13px;
            color: var(--muted);
            font-family: var(--mono);
            margin-top: 4px;
        }

        .epg-section {
            display: none;
            padding: 24px;
        }

        .epg-section.visible {
            display: block;
        }

        .section-label {
            font-family: var(--mono);
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: var(--green);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section-label::before {
            content: '';
            display: block;
            width: 4px;
            height: 14px;
            background: var(--green);
            border-radius: 2px;
            box-shadow: 0 0 8px var(--green-glow);
        }

        .epg-scroll {
            display: flex;
            gap: 16px;
            overflow-x: auto;
            padding-bottom: 8px;
            scroll-snap-type: x mandatory;
        }

        .epg-card {
            flex-shrink: 0;
            width: 260px;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--border);
            border-radius: var(--r);
            padding: 18px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            transition: all 0.3s;
            scroll-snap-align: start;
            backdrop-filter: blur(10px);
        }

        .epg-card:hover {
            background: rgba(57, 255, 20, 0.05);
            transform: translateY(-4px);
            border-color: var(--green-glow);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
        }

        .epg-card-head {
            display: flex;
            align-items: baseline;
            justify-content: space-between;
            padding-bottom: 12px;
            border-bottom: 1px dashed rgba(255, 255, 255, 0.1);
        }

        .epg-start {
            font-family: var(--mono);
            font-size: 15px;
            font-weight: 700;
            color: var(--text);
        }

        .epg-end {
            font-size: 11px;
            color: var(--muted);
            font-family: var(--mono);
        }

        .epg-show {
            font-family: var(--ff-head);
            font-size: 15px;
            font-weight: 600;
            color: #fff;
            line-height: 1.4;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .epg-desc {
            font-size: 12px;
            color: var(--muted);
            line-height: 1.5;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .epg-empty {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 40px 20px;
            width: 100%;
            text-align: center;
            background: rgba(255, 255, 255, 0.01);
            border: 1px dashed rgba(255, 255, 255, 0.08);
            border-radius: var(--r);
            color: var(--muted);
            font-size: 13px;
            font-family: var(--mono);
        }

        .related-section {
            padding: 24px;
            border-top: 1px solid var(--border);
            background: rgba(14, 14, 20, 0.4);
        }

        .related-scroll {
            display: flex;
            gap: 12px;
            overflow-x: auto;
            padding-bottom: 8px;
            scroll-snap-type: x mandatory;
        }

        .rel-card {
            flex-shrink: 0;
            width: 110px;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--r);
            padding: 16px 12px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            transition: all 0.3s;
            scroll-snap-align: start;
        }

        .rel-card:hover {
            background: rgba(57, 255, 20, 0.08);
            transform: translateY(-4px);
            border-color: var(--green);
            box-shadow: 0 8px 24px var(--green-glow);
        }

        .rel-logo {
            width: 52px;
            height: 52px;
            object-fit: contain;
            border-radius: 8px;
            background: rgba(0, 0, 0, 0.3);
            padding: 6px;
            box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .rel-name {
            font-family: var(--ff-head);
            font-size: 12px;
            font-weight: 600;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            color: var(--text);
        }

        .site-footer {
            margin-top: auto;
            padding: 24px;
            text-align: center;
            border-top: 1px solid var(--border);
            background: rgba(14, 14, 20, 0.4);
        }

        .footer-inner {
            font-family: var(--mono);
            font-size: 13px;
            color: var(--muted);
        }

        .footer-inner a {
            color: var(--green);
            text-decoration: none;
        }

        .footer-heart {
            color: var(--red);
            display: inline-block;
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.1);
            }
        }

        .hide-mobile {
            display: inline;
        }

        .shaka-video-container {
            font-family: var(--ff-body) !important;
            background: #000 !important;
        }

        .shaka-controls-container {
            z-index: 5 !important;
        }

        .shaka-spinner-container {
            display: none !important;
        }

        .shaka-play-button {
            color: var(--bg) !important;
            background-color: var(--green) !important;
            border: none !important;
            box-shadow: 0 0 15px var(--green-glow);
            transition: transform 0.2s;
        }

        .shaka-play-button:hover {
            transform: scale(1.1);
            box-shadow: 0 0 25px var(--green);
        }

        .shaka-icon-button {
            color: var(--text) !important;
            transition: color 0.2s !important;
        }

        .shaka-icon-button:hover {
            color: var(--green) !important;
        }

        .shaka-overflow-menu,
        .shaka-settings-menu {
            background: rgba(14, 14, 20, 0.95) !important;
            backdrop-filter: blur(12px) !important;
            border: 1px solid var(--border) !important;
            border-radius: 12px !important;
            color: var(--text) !important;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.8) !important;
        }

        .shaka-overflow-menu button,
        .shaka-settings-menu button {
            color: var(--text) !important;
            transition: all 0.2s !important;
            border-radius: 8px;
            margin: 2px 8px;
            width: calc(100% - 16px) !important;
        }

        .shaka-overflow-menu button:hover,
        .shaka-settings-menu button:hover {
            background: var(--green-dim) !important;
            color: var(--green) !important;
        }

        .shaka-current-selection-span {
            color: var(--green) !important;
            font-family: var(--mono) !important;
        }

        .fade-up {
            opacity: 0;
            transform: translateY(15px);
            animation: fadeup 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }

        @keyframes fadeup {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media(max-width: 600px) {
            .epg-card {
                width: 85vw;
            }

            .topbar {
                padding: 10px 16px;
            }

            .np-title {
                font-size: 20px;
            }

            .site-footer {
                padding: 8px 10px;
            }

            .footer-inner {
                font-size: 11px;
            }

            .hide-mobile {
                display: none !important;
            }
        }
    </style>
</head>

<body>
    <div class="stage">
        <header class="topbar fade-up" style="animation-delay: 0.05s">
            <a href="<?= htmlspecialchars($baseUrl) ?>/" class="back-btn">
                <svg viewBox="0 0 24 24">
                    <path d="M19 12H5M12 19l-7-7 7-7" />
                </svg>
                <span class="back-label">Back</span>
            </a>
            <div class="topbar-channel">
                <img src="<?= htmlspecialchars($channelLogo) ?>" alt="" class="topbar-logo">
                <div class="topbar-name"><?= htmlspecialchars($channelName) ?></div>
            </div>
            <span class="live-badge"><span class="live-dot"></span>LIVE</span>
        </header>

        <div class="player-main">
            <div class="video-wrap fade-up" style="animation-delay: 0.1s">
                <div class="video-aspect">
                    <div id="video-container" data-shaka-player-container
                        style="position:absolute;inset:0;background:#000;overflow:hidden;">
                        <video id="player-video" data-shaka-player playsinline></video>
                    </div>
                    <div class="ov ov-loading" id="ov-loading">
                        <div class="spinner"></div>
                        <div class="ov-loading-text">Tuning Channel...</div>
                    </div>
                    <div class="ov ov-error" id="ov-error">
                        <svg class="err-icon" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" />
                            <line x1="12" y1="8" x2="12" y2="12" />
                            <line x1="12" y1="16" x2="12.01" y2="16" />
                        </svg>
                        <div class="err-title">Stream Unavailable</div>
                        <div class="err-msg" id="err-msg">The stream could not be loaded.</div>
                        <button class="retry-btn" id="retry-btn">
                            <svg viewBox="0 0 24 24">
                                <path d="M23 4v6h-6M1 20v-6h6" />
                                <path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15" />
                            </svg>
                            Retry Connection
                        </button>
                    </div>
                </div>
            </div>

            <div class="below-player fade-up" style="animation-delay: 0.15s">
                <div class="now-playing" id="now-playing">
                    <div class="np-label"><span class="dot"></span>Now Playing</div>
                    <div class="np-title" id="np-title">—</div>
                    <div class="np-times" id="np-times"></div>
                </div>
                <div class="epg-section" id="epg-section">
                    <div class="section-label">Upcoming Schedule</div>
                    <div class="epg-scroll" id="epg-scroll"></div>
                </div>
            </div>

            <?php if (!empty($relatedChannels)): ?>
                <div class="related-section fade-up" style="animation-delay: 0.2s">
                    <div class="section-label">More in <?= htmlspecialchars($cleanGroupTitle) ?></div>
                    <div class="related-scroll">
                        <?php foreach ($relatedChannels as $rc): ?>
                            <a href="player.php?id=<?= htmlspecialchars($rc['tvg_id']) ?>" class="rel-card">
                                <img src="<?= htmlspecialchars($rc['tvg_logo']) ?>" alt="" class="rel-logo" loading="lazy">
                                <div class="rel-name"><?= htmlspecialchars($rc['tvg_name']) ?></div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <footer class="site-footer fade-up" style="animation-delay: 0.25s">
                <div class="footer-inner">
                    Crafted with <span class="footer-heart">❤️</span> by <a href="#">LazyyXD</a>
                </div>
            </footer>
        </div>
    </div>

    <script>
        (function () {
            'use strict';
            const STREAM_URL = <?= json_encode($streamUrl) ?>;
            const LICENSE_URL = <?= json_encode($licenseUrl) ?>;
            const EPG_DATA = <?= $epgJson ?>;
            const video = document.getElementById('player-video');
            const ovLoad = document.getElementById('ov-loading');
            const ovErr = document.getElementById('ov-error');
            const errMsg = document.getElementById('err-msg');
            const retryBtn = document.getElementById('retry-btn');
            let player = null, ui = null, stuckTimer = null;

            const showLoad = () => ovLoad.classList.remove('hidden');
            const hideLoad = () => ovLoad.classList.add('hidden');
            const showErr = msg => { errMsg.textContent = msg || 'Could not load the stream.'; ovErr.classList.add('show'); };
            const hideErr = () => ovErr.classList.remove('show');

            function startStuck() { clearStuck(); stuckTimer = setTimeout(() => { hideLoad(); showErr('Stream buffering timed out.'); }, 15000); }
            function clearStuck() { if (stuckTimer) { clearTimeout(stuckTimer); stuckTimer = null; } }

            async function destroyPlayer() {
                if (ui) { await ui.destroy(); ui = null; }
                if (player) { await player.destroy(); player = null; }
            }

            async function initPlayer() {
                await destroyPlayer();
                hideErr(); showLoad();
                if (!shaka.Player.isBrowserSupported()) { hideLoad(); showErr('Your browser does not support Shaka Player.'); return; }
                startStuck();
                try {
                    shaka.polyfill.installAll();
                    player = new shaka.Player(video);
                    player.configure({
                        streaming: { bufferingGoal: 15, rebufferingGoal: 5, bufferBehind: 10, retryParameters: { maxAttempts: 3, baseDelay: 1000, backoffFactor: 2 } },
                        drm: { servers: { 'com.widevine.alpha': LICENSE_URL } }
                    });
                    player.addEventListener('error', e => onErr(e.detail));
                    player.addEventListener('buffering', e => { if (e.buffering) { showLoad(); startStuck(); } else { hideLoad(); clearStuck(); } });
                    const videoContainer = document.getElementById('video-container');
                    ui = new shaka.ui.Overlay(player, videoContainer, video);
                    ui.configure({ addSeekBar: false, controlPanelElements: ['play_pause', 'time_and_duration', 'spacer', 'mute', 'volume', 'fullscreen', 'overflow_menu'], overflowMenuButtons: ['quality', 'language', 'picture_in_picture'] });
                    video.controls = false; video.autoplay = true; video.muted = false; video.volume = 1;
                    await player.load(STREAM_URL);
                    hideLoad();
                    video.play().catch(() => { video.muted = true; video.play().catch(() => { }); });
                } catch (e) { await onErr(e); }
            }

            async function onErr(e) { console.error('[Player Error]', e); clearStuck(); hideLoad(); let msg = 'Unknown streaming error occurred.'; if (e.code === 6001) msg = 'DRM decryption failed.'; else if (e.message) msg = e.message; showErr(msg); }

            video.addEventListener('playing', () => { clearStuck(); hideLoad(); });
            video.addEventListener('error', () => { if (video.error) onErr(video.error); });
            retryBtn.addEventListener('click', initPlayer);

            function renderEPG(items) {
                const now = Date.now();
                let current = null;
                let upcoming = [];
                (items || []).forEach(it => {
                    const start = parseInt(it.startTime);
                    const end = parseInt(it.endTime);
                    if (end <= now) return;
                    if (now >= start && now <= end && !current) current = it;
                    else upcoming.push(it);
                });
                if (!current && (items || []).length > 0) current = items.find(it => it.epgState === 'ON_AIR') || items[0];
                upcoming.sort((a, b) => parseInt(a.startTime) - parseInt(b.startTime));

                if (current) {
                    document.getElementById('np-title').textContent = current.title || 'Live Broadcast';
                    const sd = new Date(parseInt(current.startTime));
                    const ed = new Date(parseInt(current.endTime));
                    document.getElementById('np-times').textContent = `${sd.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} – ${ed.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
                } else {
                    document.getElementById('np-title').textContent = <?= json_encode($channelName) ?> || 'Live Broadcast';
                    document.getElementById('np-times').textContent = 'LIVE • 24x7 Stream';
                }
                document.getElementById('now-playing').classList.add('visible');

                const scroll = document.getElementById('epg-scroll');
                scroll.innerHTML = '';
                if (upcoming.length) {
                    upcoming.forEach(it => {
                        const sd = new Date(parseInt(it.startTime));
                        const ed = new Date(parseInt(it.endTime));
                        const el = document.createElement('div');
                        el.className = 'epg-card';
                        el.innerHTML = `<div class="epg-card-head"><span class="epg-start">${sd.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span><span class="epg-end">till ${ed.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></div><div class="epg-show">${it.title || 'Unknown'}</div>${it.description ? `<div class="epg-desc">${it.description}</div>` : ''}`;
                        scroll.appendChild(el);
                    });
                } else {
                    const el = document.createElement('div');
                    el.className = 'epg-empty';
                    el.innerHTML = `<svg viewBox="0 0 24 24" width="32" height="32" style="opacity:0.3;margin-bottom:10px"><path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9 9 4.03 9 9z" stroke="currentColor" fill="none" stroke-width="2"/><path d="M12 7v5l3 3" stroke="currentColor" fill="none" stroke-width="2" stroke-linecap="round"/></svg><div>Schedule data is currently unavailable.</div>`;
                    scroll.appendChild(el);
                }
                document.getElementById('epg-section').classList.add('visible');
            }

            initPlayer();
            renderEPG(EPG_DATA);
        })();
    </script>
</body>

</html>