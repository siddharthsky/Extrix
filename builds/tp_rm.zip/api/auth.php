<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/../includes/core/functions.php';

header('Content-Type: application/json; charset=utf-8');

// ─── SECURITY CHECK ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['status' => 'error', 'message' => 'Invalid request method']));
}

$token = $_POST['csrf_token'] ?? '';
if (!hash_equals($_SESSION['csrf_token'], $token)) {
    die(json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']));
}

// ─── ACTION ROUTING ─────────────────────────────────────────
$action = $_POST['action'] ?? '';

switch ($action) {
    case 'get_otp':
        $sid = trim($_POST['sid'] ?? '');
        $res = Auth::generateOtp($sid);
        echo json_encode($res);
        break;

    case 'verify_otp':
        $sid = trim($_POST['sid'] ?? '');
        $rmn = $_POST['rmn'] ?? '';
        $otp = trim($_POST['otp'] ?? '');
        $res = Auth::verifyOtp($sid, $rmn, $otp);
        if ($res && isset($res['status']) && $res['status'] === 'success') {
            ChannelUtils::downloadIfMissing();
        }
        echo json_encode($res);
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
        break;
}