<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once dirname(__DIR__) . '/includes/core/config.php';
require_once dirname(__DIR__) . '/includes/core/functions.php';

// ─── CORS PREFLIGHT ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: *');
    header('Access-Control-Max-Age: 86400');
    exit;
}

// ─── VALIDATE INPUT ─────────────────────────────────────────
$id = $_GET['id'] ?? '';

if (empty($id)) {
    http_response_code(400);
    die('Missing channel ID');
}

$originalId = str_replace('ts', '', $id);
if (!is_numeric($originalId)) {
    http_response_code(400);
    die('Invalid channel ID format');
}

// ─── GET CACHED LICENSE URL ─────────────────────────────────
$hmac = DrmHandler::getHmac($originalId);

if (!$hmac) {
    http_response_code(500);
    die('Error fetching channel details');
}

$cachedChannel = StreamCache::getChannel($originalId);
if (!$cachedChannel || empty($cachedChannel['license_url'])) {
    http_response_code(404);
    die('License data not found for this channel.');
}

$licenseUrl = $cachedChannel['license_url'];

// ─── ATTACH JWT TO LICENSE URL ──────────────────────────────
$jwt = DrmHandler::generateJwt($originalId);

if (!$jwt) {
    http_response_code(500);
    die('Failed to generate JWT for license.');
}

if (strpos($licenseUrl, '?') !== false) {
    $licenseUrl .= '&ls_session=' . $jwt;
} else {
    $licenseUrl .= '?ls_session=' . $jwt;
}

// ─── PROXY LICENSE REQUEST ──────────────────────────────────
$postData = file_get_contents('php://input');

$ch = curl_init($licenseUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postData,
    CURLOPT_HTTPHEADER => ['Content-Type: application/octet-stream'],
    CURLOPT_ENCODING => '',
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_TIMEOUT => 20,
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
curl_close($ch);

// ─── OUTPUT ─────────────────────────────────────────────────
http_response_code($httpCode);
if ($contentType) {
    header("Content-Type: $contentType");
}
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: *');

echo $response;
exit;