<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once dirname(__DIR__) . '/includes/core/config.php';
require_once dirname(__DIR__) . '/includes/core/functions.php';

$id = $_GET['id'] ?? '';
$ext = $_GET['ext'] ?? 'mpd';

/**
 * Serve fallback stream when channel is offline or geo-blocked
 */
function serveFallback(string $ext, string $type = 'offline'): void
{
    if ($type === 'geo') {
        $url = strtolower($ext) === 'm3u8'
            ? 'https://embed-cloudfront.wistia.com/deliveries/a5b3ad5a1ef03c8c323a1bf5e2e9ae731ad09d89.m3u8'
            : 'https://lazyyxd.netlify.app/geoblocked/index.mpd';
    } else {
        $url = strtolower($ext) === 'm3u8'
            ? 'https://embed-cloudfront.wistia.com/deliveries/7d82627897294931f99848c32756a9a662a0ac3e.m3u8'
            : 'https://lazyyxd.netlify.app/offline/index.mpd';
    }
    header("Location: $url");
    exit;
}

// ─── VALIDATE INPUT ─────────────────────────────────────────
if (empty($id)) {
    http_response_code(400);
    serveFallback($ext);
}

$originalId = str_replace('ts', '', $id);
if (!is_numeric($originalId)) {
    http_response_code(400);
    serveFallback($ext);
}

// ─── GEO-BLOCKING CHECK ─────────────────────────────────────
$clientIp = get_client_ip();

$localIps = ['127.0.0.1', '::1', '0.0.0.0', 'localhost'];

if (!in_array($clientIp, $localIps)) {
    $countryCode = 'IN'; // safe default if API fails

    $ctx = stream_context_create(['http' => ['timeout' => 5]]);
    $geoData = @file_get_contents("http://ip-api.com/json/{$clientIp}?fields=countryCode", false, $ctx);

    if ($geoData !== false) {
        $geoJson = json_decode($geoData, true);
        if (!empty($geoJson['countryCode'])) {
            $countryCode = strtoupper($geoJson['countryCode']);
        }
    }

    if ($countryCode !== 'IN') {
        serveFallback($ext, 'geo');
    }
}
// Localhost IPs → skip geo check, proceed normally

// ─── CHECK CATCHUP ──────────────────────────────────────────
$catchupRequest = false;
$beginFormatted = $endFormatted = null;

if (isset($_GET['begin'], $_GET['end'])) {
    $catchupRequest = true;
    $beginTimestamp = intval($_GET['begin']);
    $endTimestamp = intval($_GET['end']);
    $beginFormatted = gmdate('Ymd\THis', $beginTimestamp);
    $endFormatted = gmdate('Ymd\THis', $endTimestamp);
}

// ─── GET HMAC & CACHE ───────────────────────────────────────
$hmac = DrmHandler::getHmac($originalId);

if ($hmac === 'GEO_BLOCKED') {
    serveFallback($ext, 'geo');
} elseif (!$hmac) {
    serveFallback($ext);
}

$cachedChannel = StreamCache::getChannel($originalId);
if (!$cachedChannel || empty($cachedChannel['manifest_url'])) {
    serveFallback($ext);
}

$manifestUrl = $cachedChannel['manifest_url'];

// ─── DETECT AKAMAI PROTECTION ───────────────────────────────
$isAkamaiProtected = (strpos($manifestUrl, 'bpaita') !== false)
    || (strpos($manifestUrl, 'bpwta') !== false)
    || (strpos($manifestUrl, 'bpprod') !== false);

// If not Akamai-protected, just redirect
if (!$isAkamaiProtected) {
    header("Location: $manifestUrl");
    exit;
}

// ─── HANDLE AKAMAI MANIFEST ─────────────────────────────────
// Fix bpwta → bpaita (bpwta often throws 403)
$manifestUrl = str_replace('bpwta', 'bpaita', $manifestUrl);

if ($catchupRequest) {
    $manifestUrl = preg_replace('/(bp[aiw]+)(ta)/i', '$1catchup$2', $manifestUrl);
}

$baseUrl = dirname($manifestUrl);
$manifestUrl .= "?$hmac";

if ($catchupRequest) {
    $manifestUrl .= '&begin=' . $beginFormatted . '&end=' . $endFormatted;
}

// ─── FETCH & MODIFY MPD ─────────────────────────────────────
$mpdContent = ApiClient::fetchContent($manifestUrl);

if ($mpdContent === 'GEO_BLOCKED') {
    serveFallback($ext, 'geo');
} elseif (!$mpdContent) {
    serveFallback($ext);
}

// Inject HMAC into segments
$mpdContent = preg_replace_callback('/<SegmentTemplate\s+.*?>/', function ($matches) use ($hmac) {
    $cleaned = preg_replace('/(\$Number\$\.m4s|\$RepresentationID\$\.dash)[^"]*/', '$1', $matches[0]);
    if (!empty($hmac)) {
        return str_replace(
            ['$Number$.m4s', '$RepresentationID$.dash'],
            ['$Number$.m4s?' . $hmac, '$RepresentationID$.dash?' . $hmac],
            $cleaned
        );
    }
    return $cleaned;
}, $mpdContent);

// Fix BaseURL
if (strpos($mpdContent, '<BaseURL>') !== false) {
    $mpdContent = preg_replace('/<BaseURL>.*<\/BaseURL>/', "<BaseURL>$baseUrl/dash/</BaseURL>", $mpdContent);
} else {
    $mpdContent = preg_replace('/(<MPD[^>]*>)/', "$1\n  <BaseURL>$baseUrl/dash/</BaseURL>", $mpdContent);
}

// Replace watermark
$mpdContent = str_replace(
    '<!-- Created with Broadpeak BkS350 Origin Packager  (version=1.12.8-28913) -->',
    '<!-- Crafted with ❤️ by LazyyXD -->',
    $mpdContent
);

// ─── INJECT PSSH IF MISSING ─────────────────────────────────
if (strpos($mpdContent, 'pssh') === false && strpos($mpdContent, 'cenc:default_KID') === false) {
    $widevinePssh = DrmHandler::extractPssh($mpdContent, $baseUrl, $catchupRequest);
    if ($widevinePssh === null) {
        serveFallback($ext); // was die() before, now proper fallback
    }

    $newContent = "<!-- Common Encryption -->\n      <ContentProtection schemeIdUri=\"urn:mpeg:dash:mp4protection:2011\" value=\"cenc\" cenc:default_KID=\"{$widevinePssh['kid']}\"/>";
    $mpdContent = str_replace(
        '<ContentProtection value="cenc" schemeIdUri="urn:mpeg:dash:mp4protection:2011"/>',
        $newContent,
        $mpdContent
    );

    $pattern = '/<ContentProtection\s+schemeIdUri="(urn:[^"]+)"\s+value="Widevine"\/>/';
    $mpdContent = preg_replace_callback($pattern, function ($matches) use ($widevinePssh) {
        return "<!--Widevine-->\n      <ContentProtection schemeIdUri=\"{$matches[1]}\" value=\"Widevine\">\n        <cenc:pssh>{$widevinePssh['pssh']}</cenc:pssh>\n      </ContentProtection>";
    }, $mpdContent);

    // Fixed typo: urn:mpe:cenc → urn:mpeg:cenc
    $mpdContent = preg_replace('/xmlns="urn:mpeg:dash:schema:mpd:2011"/', '$0 xmlns:cenc="urn:mpeg:cenc:2013"', $mpdContent);
}

// ─── OUTPUT ─────────────────────────────────────────────────
header('Content-Type: application/dash+xml');
header("Content-Disposition: attachment; filename=\"lazyyxd.$ext\"");
header('Access-Control-Allow-Origin: *');
echo $mpdContent;
exit;
