<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

/**
 * Centralized HTTP Client for all Tata Play API requests
 * Eliminates duplicated cURL code across the codebase
 */
class ApiClient
{
    private const DEVICE_ID = '1e9a2d8f4bc8e37a6f201d4a9b8e7c5f';
    private const APP_VERSION = '1.62.1';
    private const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36';

    private const ANDROID_UA = 'okhttp/4.10.0';
    private const ANDROID_DEVICE_ID = 'dWvT7A9FkZ4xN2cR8pM3jL5vH1qW6yB0sX2gN8bC1mA';
    private const ANDROID_APP_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBJZCI6ImR2ci11aSIsImtleSI6IiJ9.XUQUYRo82fD_6yZ9ZEWcJkc0Os1IKbpzynLzSRtQJ-E';
    private const API_KEY = '9a8087f911b248c7945b926f254c833b';

    /**
     * Make a standard web request (Chrome UA)
     */
    public static function webRequest(string $url, ?array $postData = null, array $extraHeaders = []): array
    {
        $headers = [
            'Content-Type: application/json',
            'Accept: */*',
            'Accept-Language: en-US,en;q=0.8',
            'User-Agent: ' . self::USER_AGENT,
            'sec-ch-ua: "Chromium";v="146", "Not-A.Brand";v="24", "Brave";v="146"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'device_details: {"pl":"web","os":"WINDOWS","lo":"en-us","app":"' . self::APP_VERSION . '","dn":"PC","bv":146,"bn":"CHROME","device_id":"' . self::DEVICE_ID . '","device_type":"WEB","device_platform":"PC","device_category":"open","manufacturer":"WINDOWS_CHROME_146","model":"PC","sname":""}',
            'Referer: ' . TP_REFERER,
            'Origin: ' . TP_ORIGIN,
            'Sec-Fetch-Dest: empty',
            'Sec-Fetch-Mode: cors',
            'Sec-Fetch-Site: cross-site',
            'Pragma: no-cache',
            'Cache-Control: no-cache',
            'locale: ENG',
            'platform: web',
        ];

        $headers = array_merge($headers, $extraHeaders);

        return self::execute($url, $postData, $headers);
    }

    /**
     * Make an authenticated web request (with bearer token & profile)
     */
    public static function webAuthenticatedRequest(string $url, array $creds, ?array $postData = null, array $extraHeaders = [], bool $useBearer = true): array
    {
        $authHeader = $useBearer ? 'authorization: bearer ' . $creds['accessToken'] : 'authorization: ' . $creds['accessToken'];

        $headers = [
            'accept: */*',
            'accept-language: en-US,en;q=0.9',
            $authHeader,
            'cache-control: no-cache',
            'device_details: {"pl":"web","os":"WINDOWS","lo":"en-us","app":"1.44.7","dn":"PC","bv":129,"bn":"CHROME","device_id":"7683d93848b0f472c508e38b1827038a","device_type":"WEB","device_platform":"PC","device_category":"open","manufacturer":"WINDOWS_CHROME_129","model":"PC","sname":"' . ($creds['sname'] ?? '') . '"}',
            'platform: web',
            'pragma: no-cache',
            'profileid: ' . ($creds['profileId'] ?? ''),
            'Referer: ' . TP_REFERER,
            'Origin: ' . TP_ORIGIN,
        ];

        $headers = array_merge($headers, $extraHeaders);

        return self::execute($url, $postData, $headers);
    }

    /**
     * Make an Android-style request (for token refresh)
     */
    public static function androidRequest(string $url, string $bearerToken, ?array $postData = null): array
    {
        $headers = [
            "authorization: bearer $bearerToken",
            'accept-encoding: gzip',
            'Expect: ',
            'x-app-id: ott-app',
            'x-app-key: ' . self::ANDROID_APP_KEY,
            'x-device-id: ' . self::ANDROID_DEVICE_ID,
            'x-device-platform: MOBILE',
            'x-device-type: ANDROID',
            'device_details: {"app":"15.9","lo":"en_US","os":"9","device_id":"xxxxxxxx","ip":"xxxxxxc","dn":"xxxxx","device_type":"ANDROID","device_category":"open","manufacturer":"xxxxxx","ma":"xxxxxcccc","car":"PLATINUM","sname":"xxxxxxxc","device_platform":"MOBILE","location":"xxxxxxxxxc","model":"xxxxxxcc","pl":"Android","net":"noNetwork"}',
            'platform: Android',
            'rule: DRPVRITTA',
            'x-api-key: ' . self::API_KEY,
            'content-type: application/json; charset=UTF-8',
            'user-agent: ' . self::ANDROID_UA,
        ];

        return self::execute($url, $postData, $headers);
    }

    /**
     * Simple GET request for content fetching (manifest, segments)
     */
    public static function fetchContent(string $url, bool $wantHeaders = false): ?string
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => $wantHeaders,
            CURLOPT_NOBODY => $wantHeaders,
            CURLOPT_HTTPHEADER => [
                'User-Agent: ' . self::USER_AGENT,
                'Origin: ' . TP_ORIGIN,
                'Referer: ' . TP_REFERER,
            ],
            CURLOPT_TIMEOUT => 25,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            CURLOPT_USERAGENT => self::USER_AGENT,
        ]);

        $response = curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($responseCode === 403) {
            return 'GEO_BLOCKED';
        }

        return $responseCode === 200 ? $response : null;
    }

    /**
     * Core cURL executor
     */
    public static function execute(string $url, ?array $postData, array $headers): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_ENCODING => 'gzip, deflate',
            CURLOPT_TIMEOUT => 25,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            CURLOPT_USERAGENT => self::USER_AGENT,
        ]);

        if ($postData !== null) {
            curl_setopt($ch, CURLOPT_POST, true);
            $payload = empty($postData) ? '{}' : json_encode($postData);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return [
            'code' => $httpCode,
            'data' => json_decode($response, true),
            'raw' => $response,
        ];
    }
}
