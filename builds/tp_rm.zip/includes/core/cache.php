<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

/**
 * Stream URL and HMAC cache management
 */
class StreamCache
{
    private static ?array $data = null;

    /**
     * Load cache from disk
     */
    private static function load(): array
    {
        if (self::$data === null) {
            if (file_exists(STREAM_CACHE_FILE)) {
                self::$data = json_decode(file_get_contents(STREAM_CACHE_FILE), true) ?: [];
            } else {
                self::$data = [];
            }
        }
        return self::$data;
    }

    /**
     * Save cache to disk
     */
    private static function save(): void
    {
        $dir = dirname(STREAM_CACHE_FILE);
        if (!file_exists($dir)) {
            @mkdir($dir, 0755, true);
        }
        file_put_contents(STREAM_CACHE_FILE, json_encode(self::$data, JSON_PRETTY_PRINT));
    }

    /**
     * Store channel stream data in cache
     */
    public static function setChannel(string $channelId, array $details, int $expiryTime): void
    {
        self::load();
        self::$data[$channelId] = [
            'content' => $details,
            'exp' => $expiryTime,
        ];
        self::save();
    }

    /**
     * Retrieve channel stream data from cache
     */
    public static function getChannel(string $channelId): ?array
    {
        self::load();
        if (!isset(self::$data[$channelId])) {
            return null;
        }

        $item = self::$data[$channelId];

        // Auto-expire if less than 3 minutes remaining
        if (time() > ($item['exp'] - 180)) {
            return null;
        }

        return $item['content'];
    }

    /**
     * Retrieve only the HMAC token for a channel
     */
    public static function getHmac(string $channelId): ?string
    {
        $channel = self::getChannel($channelId);
        return $channel['hmac'] ?? null;
    }
}