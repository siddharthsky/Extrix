<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

// Production: error_reporting(0);
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// ─── PATH DEFINITIONS ───────────────────────────────────────
define('ROOT_DIR', dirname(dirname(__DIR__)));
define('CORE_DIR', ROOT_DIR . '/includes/core');
define('DATA_DIR', ROOT_DIR . '/includes/data');
define('ASSETS_DIR', ROOT_DIR . '/includes/assets');

// ─── DATA FILES ─────────────────────────────────────────────
define('ACCOUNT_FILE', DATA_DIR . '/tp-account.json');
define('CHANNELS_FILE', DATA_DIR . '/channels.json');
define('STREAM_CACHE_FILE', DATA_DIR . '/stream_url.json');

// ─── TATA PLAY API CONFIGURATION ────────────────────────────
define('TP_API_BASE', 'https://tm.tapi.videoready.tv');
define('TP_EPG_API', 'https://tb.tapi.videoready.tv');
define('TP_REFERER', 'https://watch.tataplay.com/');
define('TP_ORIGIN', 'https://watch.tataplay.com');

// ─── CHANNELS DATA SOURCE ───────────────────────────────────
define('CHANNELS_SOURCE_URL', 'https://gist.githubusercontent.com/lazyop/5d841a832562dbd950c0d46fdae99543/raw/62b3396fc82b782ee1076142bc8557c5b98d5cc1/channels');


// ─── SECURITY HEADERS ───────────────────────────────────────
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');

// ─── CSRF PROTECTION ────────────────────────────────────────
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ─── ENSURE DATA DIRECTORY EXISTS ───────────────────────────
if (!file_exists(DATA_DIR)) {
    @mkdir(DATA_DIR, 0755, true);
}

// ─── PREVENT DIRECT ACCESS ──────────────────────────────────
if (basename($_SERVER['PHP_SELF']) === 'config.php') {
    die('Direct access forbidden.');
}
