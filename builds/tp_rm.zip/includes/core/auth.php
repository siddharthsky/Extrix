<?php
//=============================================================================//
//               Project: TataPlay Localhost Playlist (Widevine)
//               Author: LazyyXD
//=============================================================================//

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/api-client.php';

/**
 * Authentication & Session Management
 */
class Auth
{
    /**
     * Check if user is authenticated via account file
     */
    public static function isLoggedIn(): bool
    {
        if (defined('ACCOUNT_FILE') && file_exists(ACCOUNT_FILE)) {
            $raw = @file_get_contents(ACCOUNT_FILE);
            if ($raw) {
                $json = json_decode($raw, true);
                if ($json && isset($json['code']) && $json['code'] === 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Get saved account credentials
     */
    public static function getAccount(): ?array
    {
        if (!defined('ACCOUNT_FILE') || !file_exists(ACCOUNT_FILE)) {
            return null;
        }

        $raw = @file_get_contents(ACCOUNT_FILE);
        if (!$raw)
            return null;

        $json = json_decode($raw, true);
        if (!$json || !isset($json['data']))
            return null;

        $d = $json['data'];
        return [
            'sid' => $d['userDetails']['sid'] ?? '',
            'sname' => $d['userDetails']['sName'] ?? '',
            'profileId' => $d['userProfile']['id'] ?? '',
            'accessToken' => $d['accessToken'] ?? '',
            'refreshToken' => $d['refreshToken'] ?? '',
            'expiresIn' => $d['expiresIn'] ?? 0,
            'acStatus' => $d['userDetails']['acStatus'] ?? '',
            'updated_at' => date('Y-m-d H:i:s', filemtime(ACCOUNT_FILE)),
            'raw_response' => $json,
        ];
    }

    /**
     * Save account JSON atomically
     */
    public static function saveAccount(array $data): bool
    {
        if (!defined('ACCOUNT_FILE'))
            return false;

        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if ($json === false)
            return false;

        $dir = dirname(ACCOUNT_FILE);
        if (!file_exists($dir)) {
            @mkdir($dir, 0755, true);
        }

        $tmp = ACCOUNT_FILE . '.tmp';
        $bytes = @file_put_contents($tmp, $json);
        if ($bytes === false)
            return false;

        return @rename($tmp, ACCOUNT_FILE);
    }

    /**
     * Rate limiting guard
     */
    public static function checkRateLimit(string $action, int $max = 5, int $period = 300): bool
    {
        if (!isset($_SESSION['limits'][$action])) {
            $_SESSION['limits'][$action] = ['count' => 0, 'start' => time()];
        }

        $limit = &$_SESSION['limits'][$action];
        if (time() - $limit['start'] > $period) {
            $limit = ['count' => 1, 'start' => time()];
            return true;
        }

        if ($limit['count'] >= $max)
            return false;
        $limit['count']++;
        return true;
    }

    /**
     * Lookup subscriber ID by registered mobile number
     */
    public static function lookupSubscriber(string $rmn): ?string
    {
        if (strlen($rmn) !== 10 || !ctype_digit($rmn))
            return null;

        $res = ApiClient::webRequest(
            rtrim(TP_API_BASE, '/') . '/login-service/pub/api/v2/subscriberLookup',
            ['rmn' => $rmn]
        );

        if ($res['data'] && $res['data']['code'] === 0 && !empty($res['data']['data']['sidList'])) {
            return $res['data']['data']['sidList'][0]['sid'];
        }

        return null;
    }

    /**
     * Generate OTP for login
     */
    public static function generateOtp(string $input): array
    {
        $input = trim($input);

        if (!self::checkRateLimit('generate_otp', 5, 300)) {
            return ['status' => 'error', 'message' => 'Too many requests. Please wait 5 minutes.'];
        }

        if (strlen($input) !== 10 || !ctype_digit($input)) {
            return ['status' => 'error', 'message' => 'Invalid SID/RMN: Must be 10 digits.'];
        }



        // Try lookup as RMN first
        $sid = self::lookupSubscriber($input);
        $rmn = $input;

        // If lookup failed, treat input as SID directly
        if (!$sid) {
            $sid = $input;
            $rmn = '';
        }

        $res = ApiClient::webRequest(
            rtrim(TP_API_BASE, '/') . '/login-service/pub/api/v2/generate/otp',
            ['sid' => $sid, 'rmn' => $rmn]
        );

        if ($res['data'] && $res['data']['code'] === 0) {
            return [
                'status' => 'success',
                'sid' => $sid,
                'rmn' => $rmn ?: ($res['data']['data']['decryptedRMN'] ?? ''),
                'message' => 'OTP sent to ' . ($res['data']['data']['decryptedRMN'] ?? 'Registered Number'),
            ];
        }

        return [
            'status' => 'error',
            'message' => $res['data']['message'] ?? 'Failed to send OTP. Please try again later.',
        ];
    }

    /**
     * Verify OTP and complete login
     */
    public static function verifyOtp(string $sid, string $rmn, string $otp): array
    {
        $sid = trim($sid);
        $otp = trim($otp);

        if (!self::checkRateLimit('verify_otp', 5, 300)) {
            return ['status' => 'error', 'message' => 'Security Lock: Too many OTP attempts.'];
        }

        if (strlen($otp) < 4 || strlen($otp) > 6 || !ctype_digit($otp)) {
            return ['status' => 'error', 'message' => 'Invalid OTP format'];
        }



        $res = ApiClient::webRequest(
            rtrim(TP_API_BASE, '/') . '/login-service/pub/api/v3/login/ott',
            [
                'rmn' => $rmn,
                'sid' => $sid,
                'authorization' => $otp,
                'loginOption' => 'OTP',
            ]
        );

        if ($res['data'] && $res['data']['code'] === 0) {
            if (!self::saveAccount($res['data'])) {
                // Silent fail - account file couldn't be written
            }
            return ['status' => 'success', 'message' => 'Authentication successful'];
        }

        return [
            'status' => 'error',
            'message' => $res['data']['message'] ?? 'Verification failed. Please check your OTP.',
        ];
    }

    /**
     * Refresh access token
     */
    public static function refreshToken(string $accessToken): array
    {
        $url = 'https://tm.tapi.videoready.tv/rest-api/v3/regenerateToken';
        $res = ApiClient::androidRequest($url, $accessToken, []);

        if ($res['code'] === 200 && is_array($res['data']) && isset($res['data']['data']['accessToken'])) {
            // Update account file with new tokens
            $raw = @file_get_contents(ACCOUNT_FILE);
            $json = json_decode($raw, true);

            if ($json && isset($json['data'])) {
                $json['data']['accessToken'] = $res['data']['data']['accessToken'];
                $json['data']['refreshToken'] = $res['data']['data']['refreshToken'] ?? $json['data']['refreshToken'];
                $json['data']['expiresIn'] = $res['data']['data']['expiresIn'] ?? $json['data']['expiresIn'];

                if (self::saveAccount($json)) {
                    return ['status' => 'success', 'message' => 'Token regenerated successfully.'];
                }
                return ['status' => 'error', 'message' => 'Token regenerated but failed to write to file.'];
            }

            return ['status' => 'error', 'message' => 'Could not read account file for update.'];
        }

        $msg = $res['data']['error_description'] ?? $res['data']['message'] ?? $res['data']['error'] ?? 'API Error or Invalid Token.';
        return ['status' => 'error', 'message' => 'Refresh failed (HTTP ' . $res['code'] . '): ' . $msg];
    }

    /**
     * Logout - delete account and destroy session
     */
    public static function logout(): void
    {
        if (defined('ACCOUNT_FILE') && file_exists(ACCOUNT_FILE)) {
            @unlink(ACCOUNT_FILE);
        }
        // Also clear stream cache
        if (defined('STREAM_CACHE_FILE') && file_exists(STREAM_CACHE_FILE)) {
            @unlink(STREAM_CACHE_FILE);
        }
        session_unset();
        session_destroy();
    }

    /**
     * Get client IP address
     */
    public static function getClientIp(): string
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        }
        return trim($ip);
    }
}
