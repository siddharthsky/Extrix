<?php
//=============================================================================//
//                            ZEE5 LIVE STREAM FETCHER                         //
//=============================================================================//
// Author        : Community Project
// Version       : 1.0
// Language      : PHP
// Purpose       : Fetch and redirect ZEE5 live stream URLs
//
//-----------------------------------------------------------------------------//
// IMPORTANT NOTICE
//-----------------------------------------------------------------------------//
// This script is provided completely FREE for educational and research
// purposes only.
//
// Selling, reselling, or including this script in any paid service is
// strictly prohibited.
//
// If someone sold you this script, you were scammed.
// The official version should always be distributed freely on GitHub.
//
//-----------------------------------------------------------------------------//
// COMPATIBILITY
//-----------------------------------------------------------------------------//
// This script works best on LOCALHOST environments such as:
//
//  • KSWeb (Android)
//  • Apache Localhost
//  • XAMPP
//  • WAMP
//
// Many shared hosting providers or VPS servers may NOT work because
// ZEE5 blocks datacenter IP addresses. If the script fails on hosting
// but works on localhost, this is likely due to IP restrictions.
//
//-----------------------------------------------------------------------------//
// USAGE
//-----------------------------------------------------------------------------//
// Upload this PHP file to a server with PHP support.
//
// Call the script with a channel ID parameter:
//
//      script.php?id=CHANNEL_ID
//
// Example:
//
//      script.php?id=0-9-251
//
// The script will:
//  1. Fetch the ZEE5 platform token
//  2. Request playback details
//  3. Extract the hdntl token
//  4. Redirect to the final HLS stream
//
//-----------------------------------------------------------------------------//
// FEATURES
//-----------------------------------------------------------------------------//
// • Automatic platform token extraction
// • Guest playback request
// • hdntl token extraction from playlist
// • hdntl token caching system (23 hours)
// • Channel list fetched from external API
//
//-----------------------------------------------------------------------------//
// REQUIREMENTS
//-----------------------------------------------------------------------------//
// • PHP 7.4 or higher
// • PHP cURL extension enabled
// • Internet connection
//
//-----------------------------------------------------------------------------//
// DISCLAIMER
//-----------------------------------------------------------------------------//
// This script does NOT host or redistribute any video content.
//
// It only fetches publicly available playback URLs from ZEE5 services.
// The developer is not responsible for misuse of this script.
//
//-----------------------------------------------------------------------------//
// LICENSE
//-----------------------------------------------------------------------------//
// This project is free to use, modify, and share for educational purposes.
//
// Selling this script or using it in paid IPTV services is NOT allowed.
//
//=============================================================================//

function grabPlatformKey(): string {

    $req = curl_init('https://www.zee5.com/live-tv/tv9-bharatvarsh/0-9-251');

    curl_setopt_array($req, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'User-Agent: SEARCHBOT - Googlebot-Mobile Smartphone (2020-01-08 Chrome/41.0.2272.96)'
        ]
    ]);

    $html = curl_exec($req);
    $status = curl_getinfo($req, CURLINFO_HTTP_CODE);

    curl_close($req);

    if ($status !== 200) {
        exit("Unable to retrieve platform key.");
    }

    preg_match('/"gwapiPlatformToken"\s*:\s*"([^"]+)"/', $html, $token);

    return $token[1] ?? '';
}


function obtainStreamLink(): string {

    $guestId = "1afd3200-3f67-4a4c-a7a8-5071e5f079c1";
    $platformKey = grabPlatformKey();

    $payload = json_encode([
        'x-access-token' => $platformKey,
        'X-Z5-Guest-Token' => $guestId,
    ]);

    $api = "https://spapi.zee5.com/singlePlayback/getDetails/secure?channel_id=0-9-251&device_id=$guestId&platform_name=desktop_web&translation=en&user_language=en,hi&country=IN&state=&app_version=4.16.3&user_type=guest&check_parental_control=false";

    $call = curl_init($api);

    curl_setopt_array($call, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_HTTPHEADER => [
            'accept: application/json',
            'content-type: application/json',
            'origin: https://www.zee5.com',
            'referer: https://www.zee5.com/',
            'user-agent: SEARCHBOT - Googlebot-Mobile Smartphone (2020-01-08 Chrome/41.0.2272.96)'
        ],
        CURLOPT_POSTFIELDS => $payload
    ]);

    $res = curl_exec($call);
    curl_close($call);

    $json = json_decode($res, true);

    if (!isset($json['keyOsDetails']['video_token'])) {
        exit("Stream URL could not be retrieved.");
    }

    return $json['keyOsDetails']['video_token'];
}


function extractHdntlToken($ua) {

    $manifest = obtainStreamLink();

    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => $manifest,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERAGENT => $ua,
        CURLOPT_FOLLOWLOCATION => true
    ]);

    $playlist = curl_exec($curl);
    $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

    curl_close($curl);

    if ($status !== 200) {
        exit("Failed to capture hdntl token.");
    }

    if (preg_match('/hdntl=([^,\s]+)/', $playlist, $found)) {
    	$token = str_replace('"', '', $found[0]);
        return $token;
    }

    exit("hdntl parameter not found.");
}

// -------------------------- hdntl Cache System -------------------------- //

function getHdntlToken($ua) {

    $cacheFile = __DIR__ . "/zee5_hdntl_cache.json";
    $cacheTime = 23 * 60 * 60;

    if (file_exists($cacheFile)) {

        $cache = json_decode(file_get_contents($cacheFile), true);

        if (!empty($cache['token']) && !empty($cache['time'])) {

            if ((time() - $cache['time']) < $cacheTime) {
                return $cache['token'];
            }
        }
    }

    $newToken = extractHdntlToken($ua);

    file_put_contents($cacheFile, json_encode([
        "token" => $newToken,
        "time" => time()
    ]));

    return $newToken;
}

// -------------------------- Main Execution -------------------------- //

$ua = $_SERVER['HTTP_USER_AGENT'] ?? "Mozilla/5.0";

$hdntlToken = getHdntlToken($ua);

$channelId = $_GET['id'] ?? '';

if (!$channelId) {
    echo json_encode(['error' => 'Missing Channel ID'], JSON_PRETTY_PRINT);
    exit;
}

$listApi = "https://zee.tgaadi.workers.dev/";

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => $listApi,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "User-Agent: Mozilla/5.0",
        "Accept: application/json"
    ]
]);

$result = curl_exec($curl);
curl_close($curl);

$channels = json_decode($result, true);

foreach ($channels as $item) {

    if ($item['id'] === $channelId) {

        $playUrl = $item['stream_url'];

        header("Location: {$playUrl}?{$hdntlToken}");
        exit;
    }
}

echo json_encode(["error" => "Channel not found"], JSON_PRETTY_PRINT);

?>

