<?php

// Remote JSON source
$json_url = "https://zee.tgaadi.workers.dev/";

// Detect current domain + folder
$base = (isset($_SERVER['HTTPS']) ? "https://" : "http://") .
        $_SERVER['HTTP_HOST'] .
        rtrim(dirname($_SERVER['PHP_SELF']), '/\\');

// Redirect script base
$stream_base = $base . "/stream.php?id=";

// Fetch JSON
$data = json_decode(file_get_contents($json_url), true);

header("Content-Type: audio/x-mpegurl");

echo "#EXTM3U\n";

foreach ($data as $channel) {

    $name  = $channel['name'] ?? 'Unknown';
    $logo  = $channel['logo'] ?? '';
    $group = $channel['genre'] ?? '';
    $id    = $channel['id'] ?? '';
    $tvgid = $channel['tvg-id'] ?? '';

    if (empty($id)) {
        continue;
    }

    $stream_url = $stream_base . urlencode($id);

    echo "#EXTINF:-1 tvg-id=\"{$tvgid}\" tvg-name=\"{$name}\" tvg-logo=\"{$logo}\" group-logo=\"https://upload.wikimedia.org/wikipedia/commons/5/5a/Zee5-official-logo.jpeg?20200410171219\" group-title=\"{$group}\",{$name}\n";
    echo $stream_url . "\n";
}

?>

