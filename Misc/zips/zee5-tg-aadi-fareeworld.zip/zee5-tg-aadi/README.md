<p align="center">
<img src="https://upload.wikimedia.org/wikipedia/commons/5/5a/Zee5-official-logo.jpeg?20200410171219" width="260">
</p>

<h1 align="center">ZEE5 Live Stream Fetcher</h1>

<p align="center">
⚡ PHP Script for generating ZEE5 Live TV M3U playlists and fetching working stream URLs.
</p>

<p align="center">
Works on Mobile, PC, Smart TVs and any IPTV player through Localhost.
</p>

---

# ⭐ Please Consider Giving a Star

If this project helped you, consider **starring the repository**.
It helps other developers discover the project.

---

# 📖 Overview

This project allows you to **generate an IPTV playlist of ZEE5 Live TV channels** using PHP.

It automatically fetches the required tokens from ZEE5 and redirects the user to the working HLS stream.

The system works using **two main scripts**:

### `playlist.php`

Creates a dynamic **M3U playlist** of ZEE5 channels.

### `stream.php`

Fetches playback tokens and redirects to the final stream URL.

---

# ⚙️ Requirements

• PHP **7.4 or higher**
• PHP **cURL extension enabled**
• Web server (Apache / Nginx)

---

# 📥 Installation

## Step 1 — Install a PHP Web Server

### For Android

Install **KSWeb**:

https://tsneh.vercel.app/ksweb_3.987.apk

### For Windows / PC

Install **XAMPP**:

https://www.apachefriends.org/download.html

---

## Step 2 — Setup the Script

Extract the files inside the **htdocs folder**.

Example directory structure:

```
htdocs/
└── zee5/
    ├── stream.php
    └── playlist.php
```

Then start the **Apache server**.

Your script is now ready to use.

---

# ▶️ Generate Playlist

Open the playlist URL:

```
http://localhost:8080/zee5/playlist.php
```

This will generate a **ZEE5 IPTV playlist**.

You can import this URL into any IPTV player.

---

# 📺 IPTV Player Usage

Add the playlist URL into your IPTV player.

Example:

```
http://localhost:8080/zee5/playlist.php
```

Supported players:

• VLC
• IPTV Smarters
• TiviMate
• OTT Navigator
• Smart IPTV

---

# 🚀 Script Features

✔ Automatic ZEE5 platform token extraction
✔ Guest playback token generation
✔ hdntl authentication token extraction
✔ Dynamic M3U playlist generation
✔ Works without ZEE5 account
✔ Lightweight PHP implementation

---

# ⚠️ Warnings

This project is **for educational purposes only**.

DO NOT:

• Sell this script
• Include it in paid IPTV services
• Misuse it for commercial purposes

If someone sold this script to you, you were **scammed**.

---

# 🙏 Credits

Original Project:

https://github.com/yuvraj824/zee5

This repository is a **modified / remake version** inspired by the original work.

Special thanks to the original developers.

---

# 📬 Support

For help or questions:

Telegram: **@tg_aadi**

---

# ⚠️ Disclaimer

This project **does not host or distribute any video content**.

The script only interacts with publicly available APIs for **educational and research purposes**.

The developer is **not responsible for misuse of this software**.

---

# 📜 License

This project is released for **free educational use**.

Selling or including this project in **commercial IPTV services** is strictly prohibited.
