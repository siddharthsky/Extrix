#!/bin/bash

# Run the Python script
python3 brightness.py

