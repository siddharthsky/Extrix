#!/bin/bash

# Navigate to the directory containing brt.py
#cd brightness.py

# Run the Python script
python3 brightness.py

